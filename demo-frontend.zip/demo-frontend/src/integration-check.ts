import { registerAuthRegisterPost, loginAuthLoginPost } from './api/client';
import axios from 'axios';

async function main() {
  const email = `check-${Date.now()}@example.com`;

  const user = await registerAuthRegisterPost({ email, password: 'supersecret1' });
  console.log('registered:', user);

  const token = await loginAuthLoginPost({ email, password: 'supersecret1' });
  console.log('logged in, token type:', token.token_type);

  try {
    await registerAuthRegisterPost({ email, password: 'supersecret1' });
    console.error('FAIL: duplicate register should have thrown');
    process.exit(1);
  } catch (e) {
    if (axios.isAxiosError(e) && e.response?.status === 409) {
      console.log('duplicate register correctly rejected:', e.response.data);
    } else {
      throw e;
    }
  }

  try {
    await loginAuthLoginPost({ email, password: 'wrongpassword' });
    console.error('FAIL: bad login should have thrown');
    process.exit(1);
  } catch (e) {
    if (axios.isAxiosError(e) && e.response?.status === 401) {
      console.log('bad login correctly rejected:', e.response.data);
    } else {
      throw e;
    }
  }

  console.log('ALL CHECKS PASSED');
}

main().catch((e) => {
  console.error('INTEGRATION CHECK FAILED', e);
  process.exit(1);
});
