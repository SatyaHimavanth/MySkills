import axios from 'axios';

export const axiosInstance = axios.create({ baseURL: 'http://127.0.0.1:8000' });

let accessToken: string | null = null;

export function setTokens(access: string) {
  accessToken = access;
}

axiosInstance.interceptors.request.use((config) => {
  if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`;
  return config;
});

// This skill configures Orval with a fetch-style HTTP client, so its custom mutator uses (url, RequestInit).
// See codegen/shared.md's Forbidden section for what breaks if this signature is wrong.
export const apiClient = <T>(url: string, options?: RequestInit): Promise<T> =>
  axiosInstance({
    url,
    method: (options?.method as any) ?? 'GET',
    headers: options?.headers as Record<string, string>,
    data: options?.body,
  }).then((response) => response.data);
