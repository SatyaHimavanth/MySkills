import { defineConfig } from 'orval';

export default defineConfig({
  api: {
    input: 'http://127.0.0.1:8000/openapi.json',
    output: {
      target: './src/api/client.ts',
      client: 'react-query',
      override: { mutator: { path: './src/api/axios-instance.ts', name: 'apiClient' } },
    },
  },
  apiZod: {
    input: 'http://127.0.0.1:8000/openapi.json',
    output: { target: './src/api/client.zod.ts', client: 'zod' },
  },
});
