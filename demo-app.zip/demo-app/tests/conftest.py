import pytest
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker

from app.core import database as db_module
from app.main import create_app
from app.security.ratelimit import InMemoryRateLimiter, get_auth_rate_limiter


@pytest.fixture
async def client():
    test_engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    test_session_local = async_sessionmaker(test_engine, expire_on_commit=False)

    db_module.engine = test_engine
    db_module.SessionLocal = test_session_local

    async def override_get_db_session():
        async with test_session_local() as session:
            yield session

    app = create_app()
    app.dependency_overrides[db_module.get_db_session] = override_get_db_session
    # Fresh limiter per test, but the SAME instance must be returned on every
    # call within that test -- FastAPI calls dependency providers fresh on every
    # request by default, so a lambda that *constructs* a new InMemoryRateLimiter
    # each call silently resets the count on every single request and the limit
    # never trips. Build the instance once here and close over that one object.
    test_rate_limiter = InMemoryRateLimiter(limit=5, window_seconds=60)
    app.dependency_overrides[get_auth_rate_limiter] = lambda: test_rate_limiter

    async with test_engine.begin() as conn:
        await conn.run_sync(db_module.Base.metadata.create_all)

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac

    await test_engine.dispose()

