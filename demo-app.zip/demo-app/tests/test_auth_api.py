import asyncio
import time

import pytest


@pytest.mark.asyncio
async def test_register_login_flow(client):
    r = await client.post(
        "/auth/register", json={"email": "a@example.com", "password": "supersecret1"}
    )
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["email"] == "a@example.com"
    assert "hashed_password" not in body

    r = await client.post(
        "/auth/login", json={"email": "a@example.com", "password": "supersecret1"}
    )
    assert r.status_code == 200, r.text
    assert "access_token" in r.json()


@pytest.mark.asyncio
async def test_duplicate_registration_returns_409(client):
    payload = {"email": "b@example.com", "password": "supersecret1"}
    await client.post("/auth/register", json=payload)
    r = await client.post("/auth/register", json=payload)
    assert r.status_code == 409
    assert r.json()["error"]["code"] == "EMAIL_ALREADY_REGISTERED"


@pytest.mark.asyncio
async def test_login_wrong_password_returns_401(client):
    await client.post(
        "/auth/register", json={"email": "c@example.com", "password": "supersecret1"}
    )
    r = await client.post(
        "/auth/login", json={"email": "c@example.com", "password": "wrongpassword"}
    )
    assert r.status_code == 401
    assert r.json()["error"]["code"] == "INVALID_CREDENTIALS"


@pytest.mark.asyncio
async def test_validation_error_shape(client):
    r = await client.post("/auth/register", json={"email": "not-an-email", "password": "x"})
    assert r.status_code == 422
    body = r.json()
    assert body["error"]["code"] == "VALIDATION_ERROR"
    assert isinstance(body["error"]["details"], list)


@pytest.mark.asyncio
async def test_rate_limit_kicks_in_on_login(client):
    payload = {"email": "d@example.com", "password": "wrongpassword"}
    statuses = []
    for _ in range(7):
        r = await client.post("/auth/login", json=payload)
        statuses.append(r.status_code)
    assert 429 in statuses


@pytest.mark.asyncio
async def test_hashing_does_not_block_the_event_loop(client):
    """Regression test for the Argon2id-blocks-the-event-loop concern documented
    in security/passwords.shared.md. Argon2id hashing is CPU-bound (~100-200ms).
    Called directly inside an async route it fully occupies the single event-loop
    thread for that duration; every other request -- including cheap, unrelated
    ones like a liveness probe -- queues behind it. Offloading to a threadpool lets
    the event loop keep serving other requests while the hash runs on a worker
    thread.

    Timing must be measured from a shared reference point captured BEFORE either
    coroutine starts, using asyncio.gather. An earlier version of this test measured
    each coroutine's own elapsed time starting from inside itself -- that hides
    blocking entirely, because a coroutine queued up behind a blocking call simply
    doesn't start its own clock until the blocking call releases the loop, so its
    self-measured duration looks fast regardless of how long it actually waited.
    """
    start = time.perf_counter()
    reg_done_at = {}
    ping_done_at = {}

    async def slow_register():
        r = await client.post(
            "/auth/register",
            json={"email": "blocking-check@example.com", "password": "supersecret1"},
        )
        reg_done_at["t"] = time.perf_counter() - start
        return r

    async def liveness_ping():
        r = await client.get("/healthz/liveness")
        ping_done_at["t"] = time.perf_counter() - start
        return r

    reg_response, ping_response = await asyncio.gather(slow_register(), liveness_ping())

    assert reg_response.status_code == 201
    assert ping_response.status_code == 200
    # The liveness probe does no hashing/DB work. If the event loop were blocked
    # by the concurrent Argon2 call, the ping could not complete until the hash
    # did (~100ms+). Offloaded, the ping should finish well before registration.
    assert ping_done_at["t"] < reg_done_at["t"], (
        f"liveness probe (t={ping_done_at['t']:.3f}s) did not finish before "
        f"registration (t={reg_done_at['t']:.3f}s) -- hashing may be blocking "
        "the event loop instead of running on a worker thread"
    )
    assert ping_done_at["t"] < 0.05


