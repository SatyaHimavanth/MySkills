class DomainError(Exception):
    """Base class for domain/business exceptions raised by the service layer."""

    code = "DOMAIN_ERROR"
    status_code = 400

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class EmailAlreadyRegisteredError(DomainError):
    code = "EMAIL_ALREADY_REGISTERED"
    status_code = 409

    def __init__(self) -> None:
        super().__init__("Email is already registered.")


class InvalidCredentialsError(DomainError):
    code = "INVALID_CREDENTIALS"
    status_code = 401

    def __init__(self) -> None:
        super().__init__("Invalid email or password.")


class UserInactiveError(DomainError):
    code = "USER_INACTIVE"
    status_code = 403

    def __init__(self) -> None:
        super().__init__("User account is inactive.")
