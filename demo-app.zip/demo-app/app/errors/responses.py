from pydantic import BaseModel


class ErrorDetail(BaseModel):
    code: str
    message: str


class ERROR_RESPONSE_SCHEMA(BaseModel):
    """Shape produced by every DomainError exception handler (see
    app/errors/handlers.py). Declared here and referenced via each route's
    `responses=` so it appears in the OpenAPI schema — FastAPI does NOT
    automatically document status codes raised by a global
    @app.exception_handler; only what a route declares gets into
    /openapi.json, and only what's in the schema reaches generated
    frontend-api-client types."""

    error: ErrorDetail
