from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.auth import router as auth_router
from app.api.health import router as health_router
from app.core.database import Base, engine
from app.errors.handlers import register_exception_handlers


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Dev-only convenience: create tables directly instead of Alembic migrations.
    # A real project promotes this to `alembic upgrade head` as a deploy step per
    # database/migrations.prod.md - never run from every API worker.
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    await engine.dispose()


def create_app() -> FastAPI:
    app = FastAPI(title="Demo App", lifespan=lifespan)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    register_exception_handlers(app)
    app.include_router(health_router)
    app.include_router(auth_router)
    return app


app = create_app()
