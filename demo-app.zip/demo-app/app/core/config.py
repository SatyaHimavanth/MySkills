from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class DatabaseSettings(BaseSettings):
    url: str = "sqlite+aiosqlite:///./dev.db"
    pool_size: int = 5
    max_overflow: int = 5

    model_config = SettingsConfigDict(env_prefix="APP_DATABASE__")


class AuthSettings(BaseSettings):
    jwt_secret: SecretStr = SecretStr("development-only-secret-please-change-32bytes-min")
    access_token_expire_minutes: int = 15
    algorithm: str = "HS256"

    model_config = SettingsConfigDict(env_prefix="APP_AUTH__")


class Settings(BaseSettings):
    environment: str = "local"
    database: DatabaseSettings = DatabaseSettings()
    auth: AuthSettings = AuthSettings()

    model_config = SettingsConfigDict(env_nested_delimiter="__")


settings = Settings()
