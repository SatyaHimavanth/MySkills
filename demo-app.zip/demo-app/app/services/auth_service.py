from sqlalchemy.ext.asyncio import AsyncSession
from starlette.concurrency import run_in_threadpool

from app.errors.domain import EmailAlreadyRegisteredError, InvalidCredentialsError, UserInactiveError
from app.models.user import User
from app.repositories.user_repo import UserRepository
from app.security.passwords import hash_password, verify_password
from app.security.tokens import create_access_token


class AuthService:
    def __init__(self, session: AsyncSession, repo: UserRepository) -> None:
        self._session = session
        self._repo = repo

    async def register(self, email: str, password: str) -> User:
        existing = await self._repo.get_by_email(email)
        if existing is not None:
            raise EmailAlreadyRegisteredError()

        # Argon2id hashing is CPU-bound and takes ~50-150ms per call. Called directly
        # inside an async def route, it blocks the single-threaded event loop for that
        # duration, serializing every concurrent request (including unrelated ones) behind
        # it. Offload to FastAPI's threadpool so the event loop stays free.
        hashed = await run_in_threadpool(hash_password, password)

        user = User(email=email, hashed_password=hashed)
        user = await self._repo.add(user)
        await self._session.commit()
        return user

    async def authenticate(self, email: str, password: str) -> tuple[str, int]:
        user = await self._repo.get_by_email(email)
        if user is None:
            # Run a dummy hash verification so failure timing doesn't leak account existence.
            await run_in_threadpool(verify_password, password, hash_password("dummy-pepper-placeholder"))
            raise InvalidCredentialsError()

        valid = await run_in_threadpool(verify_password, password, user.hashed_password)
        if not valid:
            raise InvalidCredentialsError()

        if not user.is_active:
            raise UserInactiveError()

        return create_access_token(user.id, user.token_version)
