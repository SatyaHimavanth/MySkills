from fastapi import APIRouter, Depends, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db_session

router = APIRouter(tags=["health"])


@router.get("/healthz/liveness", status_code=status.HTTP_200_OK)
async def liveness() -> dict:
    return {"status": "alive"}


@router.get("/healthz/readiness", status_code=status.HTTP_200_OK)
async def readiness(db: AsyncSession = Depends(get_db_session)) -> dict:
    await db.execute(text("SELECT 1"))
    return {"status": "ready"}
