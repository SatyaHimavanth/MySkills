from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db_session
from app.repositories.user_repo import UserRepository
from app.services.auth_service import AuthService


def get_user_repository(
    session: AsyncSession = Depends(get_db_session),
) -> UserRepository:
    return UserRepository(session)


def get_auth_service(
    session: AsyncSession = Depends(get_db_session),
    repo: UserRepository = Depends(get_user_repository),
) -> AuthService:
    return AuthService(session, repo)
