from fastapi import APIRouter, Depends, status

from app.api.deps import get_auth_service
from app.errors.domain import EmailAlreadyRegisteredError, InvalidCredentialsError
from app.errors.responses import ERROR_RESPONSE_SCHEMA
from app.schemas.user import (
    TokenResponse,
    UserLoginRequest,
    UserRegisterRequest,
    UserResponse,
)
from app.security.ratelimit import rate_limit_auth
from app.services.auth_service import AuthService

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(rate_limit_auth)],
    responses={
        status.HTTP_409_CONFLICT: {
            "model": ERROR_RESPONSE_SCHEMA,
            "description": EmailAlreadyRegisteredError.__doc__ or "Email already registered.",
        },
        status.HTTP_429_TOO_MANY_REQUESTS: {"model": ERROR_RESPONSE_SCHEMA},
    },
)
async def register(
    payload: UserRegisterRequest,
    service: AuthService = Depends(get_auth_service),
) -> UserResponse:
    user = await service.register(payload.email, payload.password)
    return UserResponse.model_validate(user)


@router.post(
    "/login",
    response_model=TokenResponse,
    dependencies=[Depends(rate_limit_auth)],
    responses={
        status.HTTP_401_UNAUTHORIZED: {
            "model": ERROR_RESPONSE_SCHEMA,
            "description": InvalidCredentialsError.__doc__ or "Invalid credentials.",
        },
        status.HTTP_429_TOO_MANY_REQUESTS: {"model": ERROR_RESPONSE_SCHEMA},
    },
)
async def login(
    payload: UserLoginRequest,
    service: AuthService = Depends(get_auth_service),
) -> TokenResponse:
    token, expires_in = await service.authenticate(payload.email, payload.password)
    return TokenResponse(access_token=token, expires_in=expires_in)

