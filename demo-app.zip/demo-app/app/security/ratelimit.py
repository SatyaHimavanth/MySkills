import time
from collections import defaultdict

from fastapi import Depends, HTTPException, Request, status


class InMemoryRateLimiter:
    """PARTIAL compatibility: process-local only, does not coordinate across
    workers/replicas. Same interface shape a Redis-backed limiter would expose,
    so swapping backends does not change call sites."""

    def __init__(self, limit: int, window_seconds: int) -> None:
        self._limit = limit
        self._window = window_seconds
        self._hits: dict[str, list[float]] = defaultdict(list)

    def check(self, key: str) -> None:
        now = time.monotonic()
        window_start = now - self._window
        hits = [t for t in self._hits[key] if t > window_start]
        if len(hits) >= self._limit:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail={"error": {"code": "RATE_LIMITED", "message": "Too many requests."}},
                headers={"Retry-After": str(self._window)},
            )
        hits.append(now)
        self._hits[key] = hits


# Module-level default instance for real (non-test) runs. Exposed only through
# the `get_auth_rate_limiter` provider below — never import this object directly
# from route/dependency code. Route code depends on the *provider*, not the
# instance, specifically so tests can override the provider with a fresh limiter
# per test via `app.dependency_overrides`. A bare module-level singleton wired
# straight into a route dependency (no provider indirection) has no reset hook,
# so state leaks across otherwise-independent tests in the same process — see
# testing/security.shared.md's "independent principals" / "reset/expiry" cases,
# which are untestable in isolation without this seam.
_default_auth_rate_limiter = InMemoryRateLimiter(limit=5, window_seconds=60)


def get_auth_rate_limiter() -> InMemoryRateLimiter:
    return _default_auth_rate_limiter


def rate_limit_auth(
    request: Request,
    limiter: InMemoryRateLimiter = Depends(get_auth_rate_limiter),
) -> None:
    key = request.client.host if request.client else "unknown"
    limiter.check(key)

