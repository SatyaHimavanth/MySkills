from datetime import UTC, datetime, timedelta

import jwt

from app.core.config import settings


def create_access_token(subject: str, token_version: int) -> tuple[str, int]:
    expire_minutes = settings.auth.access_token_expire_minutes
    expire = datetime.now(UTC) + timedelta(minutes=expire_minutes)
    payload = {
        "sub": subject,
        "tv": token_version,
        "exp": expire,
        "iat": datetime.now(UTC),
    }
    token = jwt.encode(
        payload,
        settings.auth.jwt_secret.get_secret_value(),
        algorithm=settings.auth.algorithm,
    )
    return token, expire_minutes * 60


def decode_access_token(token: str) -> dict:
    return jwt.decode(
        token,
        settings.auth.jwt_secret.get_secret_value(),
        algorithms=[settings.auth.algorithm],
    )
